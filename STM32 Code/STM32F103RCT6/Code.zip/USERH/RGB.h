#ifndef __RGB_H__
#define __RGB_H__

#include "stm32f10x.h"

void RGB_Init(void);//RGB(R: PC0 G: PC1 B: PC2)
void RGB_Control(char Color);//控制RGB显示三种颜色
	
#endif
