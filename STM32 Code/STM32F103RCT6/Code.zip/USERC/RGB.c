#include "RGB.h"

void RGB_Init(void)//RGB(R: PC0 G: PC1 B: PC2)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	/* GPIOC Periph clock enable */
	/* 使能GPIOC时钟 */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);

	/* Configure PC0、PC1 and PC2 in output pushpull mode */
	/* 配置PC0 PC1 PC2 通用推挽输出模式 */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	/* Set the GPIOC port pins */
	/* 设置PC0 1 2端口数据位 */
	GPIO_WriteBit(GPIOC, GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2, Bit_RESET);
}

void RGB_Control(char Color)//控制RGB显示三种颜色
{
	switch(Color)
	{
		case 'R':// Red 		RGB: 1 0 0(数字是表示对应灯需要亮 并不是对应引脚电平 RGB灯低电平点亮 刚好相反)
			GPIO_WriteBit(GPIOC, GPIO_Pin_0 , Bit_RESET);
			GPIO_WriteBit(GPIOC, GPIO_Pin_1 | GPIO_Pin_2, Bit_SET);
			break;
		case 'G':// Green 	RGB: 0 1 0
			GPIO_WriteBit(GPIOC, GPIO_Pin_1 , Bit_RESET);
			GPIO_WriteBit(GPIOC, GPIO_Pin_0 | GPIO_Pin_2, Bit_SET);
			break;
		case 'B':// Blue 		RGB: 0 0 1
			GPIO_WriteBit(GPIOC, GPIO_Pin_2 , Bit_RESET);
			GPIO_WriteBit(GPIOC, GPIO_Pin_0 | GPIO_Pin_1, Bit_SET);
			break;
		case 'Y':// Yellow 	RGB: 1 1 0
			GPIO_WriteBit(GPIOC, GPIO_Pin_2 , Bit_SET);
			GPIO_WriteBit(GPIOC, GPIO_Pin_0 | GPIO_Pin_1, Bit_RESET);
			break;
		case 'C':// Cyan 		RGB: 0 1 1
			GPIO_WriteBit(GPIOC, GPIO_Pin_0 , Bit_SET);
			GPIO_WriteBit(GPIOC, GPIO_Pin_1 | GPIO_Pin_2, Bit_RESET);
			break;
		case 'W':// White 	RGB: 1 1 1
			GPIO_WriteBit(GPIOC, GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2, Bit_RESET);
			break;
	}
}
