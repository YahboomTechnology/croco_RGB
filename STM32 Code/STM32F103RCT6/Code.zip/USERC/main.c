#include "stm32f10x.h"
#include "SysTick.h"
#include "LED.h"
#include "RGB.h"

int main(void)
{
	SysTick_Init();//滴答定时器初始化
    LED_Init();//LED初始化(PB4)
    RGB_Init();//RGB(R: PC0 G: PC1 B: PC2)
	
    while(1)
    {
			RGB_Control('R');	//RGB：红色
			Delay_us(1000000);	//延时1秒
			RGB_Control('G');	//RGB：绿色
			Delay_us(1000000);	//延时1秒
			RGB_Control('B');	//RGB：蓝色
			Delay_us(1000000);	//延时1秒
			RGB_Control('Y');	//RGB：黄色
			Delay_us(1000000);	//延时1秒
			RGB_Control('C');	//RGB：青色
			Delay_us(1000000);	//延时1秒
			RGB_Control('W');	//RGB：白色
			Delay_us(1000000);	//延时1秒
    }
}
